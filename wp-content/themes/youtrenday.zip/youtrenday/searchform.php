<div id="bbpress-forums" class="bbpress-wrapper">

	
	<div class="bbp-search-form">
		<form role="search" method="get" id="bbp-search-form">
			<div>
				<label class="screen-reader-text hidden" for="bbp_search">Search for:</label>
				<input type="hidden" name="action" value="bbp-search-request">
				<input type="text" value="" name="bbp_search" id="bbp_search">
				<span class="bb_ctm_btn"><input class="button" type="submit" id="bbp_search_submit" value="Search"></span>
			</div>
		</form>
	</div>


	
	
	
	
		
<ul id="forums-list-0" class="bbp-forums">

	<li class="bbp-header">

		<ul class="forum-titles">
			<li class="bbp-forum-info">Forum</li>
			<li class="bbp-forum-topic-count">Topics</li>
			<li class="bbp-forum-reply-count">Posts</li>
			<li class="bbp-forum-freshness">Last Post</li>
		</ul>

	</li><!-- .bbp-header -->

	<li class="bbp-body">

		
			
<ul id="bbp-forum-817" class="loop-item-0 bbp-forum-status-open bbp-forum-visibility-publish odd  post-817 forum type-forum status-publish hentry">
	<li class="bbp-forum-info">

		
		
		<a class="bbp-forum-title" href="https://localhost/mackenzie_borys/forums/forum/demo-forum/">Demo Forum</a>

		
		
		<div class="bbp-forum-content">Demo Content Demo Content Demo Content Demo Content Demo Content</div>

		
		
		
		
		
	</li>

	<li class="bbp-forum-topic-count">4</li>

	<li class="bbp-forum-reply-count">6</li>

	<li class="bbp-forum-freshness">

		
		<a href="https://localhost/mackenzie_borys/forums/topic/demo-topic-3/" title="Demo Topic 3">3 hours, 46 minutes ago</a>
		
		<p class="bbp-topic-meta">

			
			<span class="bbp-topic-freshness-author"><a href="https://localhost/mackenzie_borys/members/admin/" title="View admin's profile" class="bbp-author-link"><span class="bbp-author-avatar"><img alt="" src="https://localhost/mackenzie_borys/wp-content/uploads/avatars/1/5ec8c4c539a2c-bpthumb.png" srcset="https://localhost/mackenzie_borys/wp-content/uploads/avatars/1/5ec8c4c539a2c-bpthumb.png 2x" class="avatar avatar-14 photo" height="14" width="14"></span><span class="bbp-author-name">admin</span></a></span>

			
		</p>
	</li>
</ul><!-- #bbp-forum-817 -->

		
	</li><!-- .bbp-body -->

	<li class="bbp-footer">

		<div class="tr">
			<p class="td colspan4">&nbsp;</p>
		</div><!-- .tr -->

	</li><!-- .bbp-footer -->

</ul><!-- .forums-directory -->


	
	
</div>