<?php
/**
 * BP Nouveau Default user's front template.
 *
 * @since 3.0.0
 * @version 3.1.0
 */
// echo 'userid = '. bp_displayed_user_id() ;
?>
<?php get_posts_shortcode("music"); ?>