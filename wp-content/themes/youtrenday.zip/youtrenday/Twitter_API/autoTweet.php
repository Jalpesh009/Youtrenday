<?php

include('TwitterPoster.php');

# Send a random Tweet for us
TwitterPoster::randomTweet();

?>
